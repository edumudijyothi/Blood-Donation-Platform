import React from 'react';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import RequestForm from '../components/blood-request/RequestForm';
import { AlertTriangle } from 'lucide-react';

const RequestBloodPage: React.FC = () => {
  const handleSubmit = (formData: any) => {
    // This would connect to your backend API
    console.log("Request submitted:", formData);
    // Show success message, redirect, etc.
    alert("Your request has been submitted. We'll contact you shortly with potential matches.");
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Request Blood Donation</h1>
            <p className="max-w-2xl mx-auto text-lg text-gray-600">
              Need blood for a patient? Fill out the form below to submit a request.
              We'll match you with eligible donors in your area.
            </p>
          </div>
          
          <div className="bg-orange-50 border-l-4 border-orange-500 p-4 mb-8 rounded">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-orange-500" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-orange-800">Emergency Need?</h3>
                <div className="mt-2 text-orange-700">
                  <p>
                    If this is a medical emergency requiring immediate blood, please contact your
                    local hospital or emergency services directly at <strong>911</strong> or the nearest 
                    hospital blood bank.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <RequestForm onSubmit={handleSubmit} />
            </div>
            
            <div>
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Blood Request Tips</h3>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-red-100 text-red-800 font-semibold text-sm mr-2 mt-0.5">1</span>
                    <span>Provide accurate contact information so donors can reach you.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-red-100 text-red-800 font-semibold text-sm mr-2 mt-0.5">2</span>
                    <span>Include detailed location information to help find nearby donors.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-red-100 text-red-800 font-semibold text-sm mr-2 mt-0.5">3</span>
                    <span>Be specific about the urgency level to ensure appropriate response.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-red-100 text-red-800 font-semibold text-sm mr-2 mt-0.5">4</span>
                    <span>Consider compatible blood types if your specific type is unavailable.</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Blood Type Compatibility</h3>
                <p className="text-gray-700 mb-4">
                  If your exact blood type isn't available, knowing compatible types can be 
                  life-saving:
                </p>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm">
                    <thead>
                      <tr className="bg-red-50">
                        <th className="px-4 py-2 text-left text-red-800">Patient Blood Type</th>
                        <th className="px-4 py-2 text-left text-red-800">Can Receive From</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      <tr>
                        <td className="px-4 py-2 font-medium">A+</td>
                        <td className="px-4 py-2">A+, A-, O+, O-</td>
                      </tr>
                      <tr>
                        <td className="px-4 py-2 font-medium">A-</td>
                        <td className="px-4 py-2">A-, O-</td>
                      </tr>
                      <tr>
                        <td className="px-4 py-2 font-medium">B+</td>
                        <td className="px-4 py-2">B+, B-, O+, O-</td>
                      </tr>
                      <tr>
                        <td className="px-4 py-2 font-medium">B-</td>
                        <td className="px-4 py-2">B-, O-</td>
                      </tr>
                      <tr>
                        <td className="px-4 py-2 font-medium">AB+</td>
                        <td className="px-4 py-2">All blood types</td>
                      </tr>
                      <tr>
                        <td className="px-4 py-2 font-medium">AB-</td>
                        <td className="px-4 py-2">A-, B-, AB-, O-</td>
                      </tr>
                      <tr>
                        <td className="px-4 py-2 font-medium">O+</td>
                        <td className="px-4 py-2">O+, O-</td>
                      </tr>
                      <tr>
                        <td className="px-4 py-2 font-medium">O-</td>
                        <td className="px-4 py-2">O- only</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default RequestBloodPage;