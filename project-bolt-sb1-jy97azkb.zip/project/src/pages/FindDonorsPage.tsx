import React, { useState } from 'react';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import { MapPin, Filter, Search, Heart } from 'lucide-react';
import { BloodType, Donor } from '../types';

// Mock data for demonstration
const mockDonors: Donor[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john@example.com',
    role: 'donor',
    bloodType: 'O+',
    lastDonation: new Date('2023-10-15'),
    donationCount: 8,
    eligibleToDonateSince: new Date('2024-01-15'),
    medicalConditions: [],
    badges: [
      { id: '1', name: 'Gold Donor', description: '5+ donations', icon: 'award', earnedAt: new Date('2023-05-20') }
    ],
    location: {
      latitude: 37.7749,
      longitude: -122.4194,
      address: '123 Market St',
      city: 'San Francisco',
      state: 'CA',
      country: 'USA',
      zipCode: '94103'
    },
    createdAt: new Date('2022-01-10')
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah@example.com',
    role: 'donor',
    bloodType: 'A-',
    lastDonation: new Date('2023-11-22'),
    donationCount: 3,
    eligibleToDonateSince: new Date('2024-02-22'),
    medicalConditions: [],
    badges: [
      { id: '2', name: 'Regular Donor', description: '3+ donations', icon: 'star', earnedAt: new Date('2023-07-15') }
    ],
    location: {
      latitude: 37.7833,
      longitude: -122.4167,
      address: '456 Mission St',
      city: 'San Francisco',
      state: 'CA',
      country: 'USA',
      zipCode: '94105'
    },
    createdAt: new Date('2022-03-15')
  },
  {
    id: '3',
    name: 'Michael Chen',
    email: 'michael@example.com',
    role: 'donor',
    bloodType: 'AB+',
    lastDonation: new Date('2023-12-05'),
    donationCount: 12,
    eligibleToDonateSince: new Date('2024-03-05'),
    medicalConditions: [],
    badges: [
      { id: '3', name: 'Platinum Donor', description: '10+ donations', icon: 'award', earnedAt: new Date('2023-02-10') }
    ],
    location: {
      latitude: 37.7935,
      longitude: -122.3939,
      address: '789 Montgomery St',
      city: 'San Francisco',
      state: 'CA',
      country: 'USA',
      zipCode: '94111'
    },
    createdAt: new Date('2021-08-20')
  },
  {
    id: '4',
    name: 'Emily Davis',
    email: 'emily@example.com',
    role: 'donor',
    bloodType: 'O-',
    lastDonation: new Date('2024-01-10'),
    donationCount: 6,
    eligibleToDonateSince: new Date('2024-04-10'),
    medicalConditions: [],
    badges: [
      { id: '4', name: 'Silver Donor', description: '5+ donations', icon: 'award', earnedAt: new Date('2023-09-05') }
    ],
    location: {
      latitude: 37.7694,
      longitude: -122.4862,
      address: '321 Sunset Blvd',
      city: 'San Francisco',
      state: 'CA',
      country: 'USA',
      zipCode: '94122'
    },
    createdAt: new Date('2022-05-15')
  }
];

const FindDonorsPage: React.FC = () => {
  const [bloodType, setBloodType] = useState<BloodType | 'all'>('all');
  const [location, setLocation] = useState('');
  const [distance, setDistance] = useState('25');
  const [availableOnly, setAvailableOnly] = useState(true);
  const [donors, setDonors] = useState<Donor[]>(mockDonors);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Filter logic would connect to your backend API
    // For demo, we'll just filter the mock data
    let filteredDonors = [...mockDonors];
    
    if (bloodType !== 'all') {
      filteredDonors = filteredDonors.filter(donor => donor.bloodType === bloodType);
    }
    
    if (location) {
      // In a real app, you'd use geocoding to match location
      filteredDonors = filteredDonors.filter(donor => 
        donor.location.city.toLowerCase().includes(location.toLowerCase()) ||
        donor.location.state.toLowerCase().includes(location.toLowerCase()) ||
        donor.location.zipCode.includes(location)
      );
    }
    
    if (availableOnly) {
      const now = new Date();
      filteredDonors = filteredDonors.filter(donor => 
        donor.eligibleToDonateSince && donor.eligibleToDonateSince <= now
      );
    }
    
    setDonors(filteredDonors);
  };
  
  const bloodTypes: BloodType[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  
  const isEligible = (donor: Donor): boolean => {
    if (!donor.eligibleToDonateSince) return false;
    return new Date() >= donor.eligibleToDonateSince;
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Find Blood Donors</h1>
            <p className="max-w-2xl mx-auto text-lg text-gray-600">
              Search for eligible donors by blood type and location to connect with potential donors for your needs.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <form onSubmit={handleSearch}>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Blood Type</label>
                  <select 
                    value={bloodType}
                    onChange={(e) => setBloodType(e.target.value as BloodType | 'all')}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                  >
                    <option value="all">All Blood Types</option>
                    {bloodTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                  <div className="relative">
                    <input 
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="City, State, or Zip"
                      className="w-full p-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                    />
                    <MapPin className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Distance (miles)</label>
                  <select 
                    value={distance}
                    onChange={(e) => setDistance(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                  >
                    <option value="10">10 miles</option>
                    <option value="25">25 miles</option>
                    <option value="50">50 miles</option>
                    <option value="100">100 miles</option>
                  </select>
                </div>
                
                <div className="flex items-end">
                  <button 
                    type="submit" 
                    className="w-full p-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors flex items-center justify-center"
                  >
                    <Search className="h-5 w-5 mr-2" />
                    Search Donors
                  </button>
                </div>
              </div>
              
              <div className="mt-4 flex items-center">
                <input
                  type="checkbox"
                  id="availableOnly"
                  checked={availableOnly}
                  onChange={(e) => setAvailableOnly(e.target.checked)}
                  className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                />
                <label htmlFor="availableOnly" className="ml-2 text-sm text-gray-700">
                  Show only donors eligible to donate now
                </label>
              </div>
            </form>
          </div>
          
          <div className="mb-6 flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-800">
              {donors.length} Donors Found
            </h2>
            <div className="flex items-center">
              <Filter className="h-5 w-5 text-gray-500 mr-1" />
              <span className="text-sm text-gray-600">Filter</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {donors.map(donor => (
              <div key={donor.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center">
                      <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                        <Heart className="h-6 w-6 text-red-600" />
                      </div>
                      <div className="ml-3">
                        <h3 className="text-lg font-semibold text-gray-800">{donor.name}</h3>
                        <div className="flex items-center text-gray-600 text-sm">
                          <MapPin className="h-4 w-4 mr-1" />
                          <span>{donor.location.city}, {donor.location.state}</span>
                        </div>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-medium">
                      {donor.bloodType}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-500">Last Donation</p>
                      <p className="font-medium">{donor.lastDonation?.toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Total Donations</p>
                      <p className="font-medium">{donor.donationCount}</p>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-gray-500">Donation Status</span>
                      <span className={`text-sm font-medium ${isEligible(donor) ? 'text-green-600' : 'text-orange-600'}`}>
                        {isEligible(donor) ? 'Available Now' : 'Available from ' + donor.eligibleToDonateSince?.toLocaleDateString()}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div 
                        className={`h-2.5 rounded-full ${isEligible(donor) ? 'bg-green-600' : 'bg-orange-400'}`}
                        style={{ width: isEligible(donor) ? '100%' : '50%' }}
                      ></div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2 mb-4">
                    {donor.badges.map(badge => (
                      <span 
                        key={badge.id}
                        className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-medium"
                      >
                        {badge.name}
                      </span>
                    ))}
                  </div>
                  
                  <div className="flex justify-between">
                    <button className="px-4 py-2 bg-white border border-red-600 text-red-600 rounded-lg text-sm font-medium hover:bg-red-50 transition-colors">
                      View Profile
                    </button>
                    <button className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors">
                      Contact Donor
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default FindDonorsPage;