import React from 'react';
import HeroSection from '../components/home/HeroSection';
import StatsSection from '../components/home/StatsSection';
import ProcessSection from '../components/home/ProcessSection';
import BloodTypeInfoSection from '../components/home/BloodTypeInfoSection';
import TestimonialsSection from '../components/home/TestimonialsSection';

const HomePage: React.FC = () => {
  return (
    <div>
      <HeroSection />
      <StatsSection />
      <ProcessSection />
      <BloodTypeInfoSection />
      <TestimonialsSection />
    </div>
  );
};

export default HomePage;