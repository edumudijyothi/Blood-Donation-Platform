import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import HomePage from './pages/HomePage';
import RequestBloodPage from './pages/RequestBloodPage';
import FindDonorsPage from './pages/FindDonorsPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="flex flex-col min-h-screen">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/request" element={<RequestBloodPage />} />
            <Route path="/find-donors" element={<FindDonorsPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route 
              path="*" 
              element={
                <>
                  <Navbar />
                  <div className="flex-grow flex items-center justify-center pt-16">
                    <div className="text-center">
                      <h2 className="text-2xl font-bold text-gray-800 mb-2">Page Under Construction</h2>
                      <p className="text-gray-600">This page is coming soon. Please check back later.</p>
                      <a 
                        href="/" 
                        className="mt-4 inline-block px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                      >
                        Return Home
                      </a>
                    </div>
                  </div>
                  <Footer />
                </>
              } 
            />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;