import React from 'react';
import { Heart, Mail, Phone, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white pt-12 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Heart className="h-6 w-6 text-red-500" />
              <span className="ml-2 text-xl font-bold">LifeFlow</span>
            </div>
            <p className="text-gray-300 mb-4">
              Connecting donors to those in need, one drop at a time. Our mission is to make blood donation accessible, 
              efficient, and life-saving.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/" className="text-gray-300 hover:text-white">Home</a></li>
              <li><a href="/donate" className="text-gray-300 hover:text-white">Donate Blood</a></li>
              <li><a href="/request" className="text-gray-300 hover:text-white">Request Blood</a></li>
              <li><a href="/find-donors" className="text-gray-300 hover:text-white">Find Donors</a></li>
              <li><a href="/learn" className="text-gray-300 hover:text-white">Learn About Donation</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><a href="/eligibility" className="text-gray-300 hover:text-white">Eligibility</a></li>
              <li><a href="/process" className="text-gray-300 hover:text-white">Donation Process</a></li>
              <li><a href="/faq" className="text-gray-300 hover:text-white">FAQs</a></li>
              <li><a href="/hospitals" className="text-gray-300 hover:text-white">Partner Hospitals</a></li>
              <li><a href="/research" className="text-gray-300 hover:text-white">Blood Research</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <Phone size={18} className="mr-2 text-red-500" />
                <span className="text-gray-300">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <Mail size={18} className="mr-2 text-red-500" />
                <span className="text-gray-300">contact@lifeflow.org</span>
              </li>
              <li className="flex items-start">
                <MapPin size={18} className="mr-2 mt-1 text-red-500" />
                <span className="text-gray-300">123 Donation Street, Medical District, City, Country</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">&copy; {new Date().getFullYear()} LifeFlow. All rights reserved.</p>
            <div className="mt-4 md:mt-0 flex space-x-6">
              <a href="/terms" className="text-gray-400 hover:text-white text-sm">Terms of Service</a>
              <a href="/privacy" className="text-gray-400 hover:text-white text-sm">Privacy Policy</a>
              <a href="/cookies" className="text-gray-400 hover:text-white text-sm">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;