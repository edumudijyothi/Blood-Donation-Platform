import React, { useState } from 'react';
import { Menu, X, Heart, Droplet as DropletPlus, MapPin, Calendar, Award, BookOpen, LogIn, UserCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface NavItemProps {
  icon: React.ReactNode;
  text: string;
  active?: boolean;
  onClick?: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, text, active, onClick }) => {
  return (
    <li>
      <button
        onClick={onClick}
        className={`flex items-center p-2 rounded-lg w-full ${
          active 
            ? 'text-white bg-red-600' 
            : 'text-gray-700 hover:bg-red-50'
        }`}
      >
        <span className="mr-3">{icon}</span>
        <span>{text}</span>
      </button>
    </li>
  );
};

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const navItems = [
    { text: 'Donate Blood', icon: <DropletPlus size={20} className="text-red-600" />, path: '/donate' },
    { text: 'Find Donors', icon: <MapPin size={20} className="text-red-600" />, path: '/find-donors' },
    { text: 'Request Blood', icon: <Heart size={20} className="text-red-600" />, path: '/request' },
    { text: 'Appointments', icon: <Calendar size={20} className="text-red-600" />, path: '/appointments' },
    { text: 'Achievements', icon: <Award size={20} className="text-red-600" />, path: '/achievements' },
    { text: 'Learn', icon: <BookOpen size={20} className="text-red-600" />, path: '/learn' },
  ];

  return (
    <nav className="bg-white shadow-md fixed w-full z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Heart className="h-8 w-8 text-red-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">LifeFlow</span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            {navItems.map((item) => (
              <a 
                key={item.text}
                href={item.path}
                className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-red-600 hover:bg-red-50 transition-colors"
              >
                <div className="flex items-center">
                  {item.icon}
                  <span className="ml-1">{item.text}</span>
                </div>
              </a>
            ))}
            
            {isAuthenticated ? (
              <div className="flex items-center space-x-2">
                <a href="/profile" className="flex items-center px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-red-600 hover:bg-red-50">
                  <UserCircle size={20} className="text-red-600 mr-1" />
                  <span>{user?.name || 'Profile'}</span>
                </a>
                <button 
                  onClick={logout}
                  className="px-4 py-2 rounded-md bg-red-600 text-white hover:bg-red-700 transition-colors"
                >
                  Logout
                </button>
              </div>
            ) : (
              <a 
                href="/login"
                className="flex items-center px-4 py-2 rounded-md bg-red-600 text-white hover:bg-red-700 transition-colors"
              >
                <LogIn size={18} className="mr-1" />
                <span>Login</span>
              </a>
            )}
          </div>
          
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-red-600 hover:bg-red-50 focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white shadow-lg">
            <ul className="space-y-2">
              {navItems.map((item) => (
                <NavItem
                  key={item.text}
                  icon={item.icon}
                  text={item.text}
                  onClick={() => {
                    setIsMenuOpen(false);
                    window.location.href = item.path;
                  }}
                />
              ))}
              
              {isAuthenticated ? (
                <>
                  <NavItem
                    icon={<UserCircle size={20} className="text-red-600" />}
                    text="My Profile"
                    onClick={() => {
                      setIsMenuOpen(false);
                      window.location.href = '/profile';
                    }}
                  />
                  <li>
                    <button
                      onClick={() => {
                        logout();
                        setIsMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 mt-2 rounded-md bg-red-600 text-white hover:bg-red-700 transition-colors"
                    >
                      Logout
                    </button>
                  </li>
                </>
              ) : (
                <li>
                  <a
                    href="/login"
                    className="flex items-center w-full px-4 py-2 mt-2 rounded-md bg-red-600 text-white hover:bg-red-700 transition-colors"
                  >
                    <LogIn size={18} className="mr-1" />
                    <span>Login</span>
                  </a>
                </li>
              )}
            </ul>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;