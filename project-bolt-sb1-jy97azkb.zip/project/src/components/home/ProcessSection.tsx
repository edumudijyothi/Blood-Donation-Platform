import React from 'react';
import { UserCheck, Droplet, Calendar, Award } from 'lucide-react';

interface ProcessStepProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  step: number;
}

const ProcessStep: React.FC<ProcessStepProps> = ({ icon, title, description, step }) => {
  return (
    <div className="flex flex-col items-center text-center">
      <div className="relative">
        <div className="w-16 h-16 rounded-full bg-red-600 flex items-center justify-center mb-4 z-10 relative">
          {icon}
        </div>
        {step < 4 && (
          <div className="absolute top-8 left-16 w-full h-1 bg-red-200 hidden md:block"></div>
        )}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const ProcessSection: React.FC = () => {
  const steps = [
    {
      icon: <UserCheck className="h-8 w-8 text-white" />,
      title: "Register",
      description: "Create your account with your blood type and basic information.",
      step: 1
    },
    {
      icon: <Calendar className="h-8 w-8 text-white" />,
      title: "Schedule",
      description: "Book an appointment at a donation center near you.",
      step: 2
    },
    {
      icon: <Droplet className="h-8 w-8 text-white" />,
      title: "Donate",
      description: "Give blood at your scheduled time. It only takes about 10 minutes!",
      step: 3
    },
    {
      icon: <Award className="h-8 w-8 text-white" />,
      title: "Save Lives",
      description: "Your donation can save up to 3 lives and earn you badges.",
      step: 4
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-600">
            Donating blood is a simple process that takes just a few minutes but can save multiple lives.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {steps.map((step) => (
            <ProcessStep
              key={step.step}
              icon={step.icon}
              title={step.title}
              description={step.description}
              step={step.step}
            />
          ))}
        </div>
        
        <div className="mt-16 bg-red-50 rounded-lg p-8 max-w-4xl mx-auto">
          <h3 className="text-2xl font-semibold text-center mb-6">Ready to Make a Difference?</h3>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a 
              href="/register"
              className="px-6 py-3 rounded-lg bg-red-600 text-white font-semibold text-center hover:bg-red-700 transition-colors"
            >
              Register as a Donor
            </a>
            <a 
              href="/learn"
              className="px-6 py-3 rounded-lg bg-white text-red-600 border border-red-600 font-semibold text-center hover:bg-red-50 transition-colors"
            >
              Learn More
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;