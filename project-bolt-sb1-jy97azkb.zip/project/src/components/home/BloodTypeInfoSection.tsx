import React from 'react';
import { BloodType } from '../../types';

interface BloodTypeCardProps {
  bloodType: BloodType;
  canDonateTo: BloodType[];
  canReceiveFrom: BloodType[];
  percentage: string;
}

const BloodTypeCard: React.FC<BloodTypeCardProps> = ({ 
  bloodType, 
  canDonateTo, 
  canReceiveFrom, 
  percentage 
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="bg-red-600 p-4">
        <h3 className="text-white text-2xl font-bold text-center">{bloodType}</h3>
      </div>
      <div className="p-5">
        <div className="mb-3">
          <p className="text-sm text-gray-500">Population Percentage</p>
          <p className="text-xl font-semibold">{percentage}</p>
        </div>
        
        <div className="mb-3">
          <p className="text-sm text-gray-500">Can Donate To</p>
          <div className="flex flex-wrap gap-2 mt-1">
            {canDonateTo.map((type) => (
              <span 
                key={`donate-${type}`}
                className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium"
              >
                {type}
              </span>
            ))}
          </div>
        </div>
        
        <div>
          <p className="text-sm text-gray-500">Can Receive From</p>
          <div className="flex flex-wrap gap-2 mt-1">
            {canReceiveFrom.map((type) => (
              <span 
                key={`receive-${type}`}
                className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
              >
                {type}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const BloodTypeInfoSection: React.FC = () => {
  const bloodTypeInfo: BloodTypeCardProps[] = [
    {
      bloodType: 'O-',
      canDonateTo: ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
      canReceiveFrom: ['O-'],
      percentage: '7% of population'
    },
    {
      bloodType: 'O+',
      canDonateTo: ['O+', 'A+', 'B+', 'AB+'],
      canReceiveFrom: ['O-', 'O+'],
      percentage: '38% of population'
    },
    {
      bloodType: 'A-',
      canDonateTo: ['A-', 'A+', 'AB-', 'AB+'],
      canReceiveFrom: ['O-', 'A-'],
      percentage: '6% of population'
    },
    {
      bloodType: 'A+',
      canDonateTo: ['A+', 'AB+'],
      canReceiveFrom: ['O-', 'O+', 'A-', 'A+'],
      percentage: '34% of population'
    },
    {
      bloodType: 'B-',
      canDonateTo: ['B-', 'B+', 'AB-', 'AB+'],
      canReceiveFrom: ['O-', 'B-'],
      percentage: '2% of population'
    },
    {
      bloodType: 'B+',
      canDonateTo: ['B+', 'AB+'],
      canReceiveFrom: ['O-', 'O+', 'B-', 'B+'],
      percentage: '9% of population'
    },
    {
      bloodType: 'AB-',
      canDonateTo: ['AB-', 'AB+'],
      canReceiveFrom: ['O-', 'A-', 'B-', 'AB-'],
      percentage: '1% of population'
    },
    {
      bloodType: 'AB+',
      canDonateTo: ['AB+'],
      canReceiveFrom: ['All blood types'],
      percentage: '3% of population'
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Blood Type Compatibility</h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-600">
            Understanding blood type compatibility is crucial for successful transfusions. 
            Learn which blood types you can donate to and receive from.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {bloodTypeInfo.map((info) => (
            <BloodTypeCard 
              key={info.bloodType}
              bloodType={info.bloodType}
              canDonateTo={info.canDonateTo}
              canReceiveFrom={info.canReceiveFrom}
              percentage={info.percentage}
            />
          ))}
        </div>
        
        <div className="mt-12 bg-white rounded-lg shadow-md p-6 max-w-3xl mx-auto">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Universal Donors and Recipients</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-green-50 rounded-lg p-4">
              <h4 className="font-medium text-green-800 mb-2">Universal Donor (O-)</h4>
              <p className="text-gray-700">
                O- blood can be given to anyone, regardless of their blood type. 
                This makes O- donors extremely valuable, especially in emergency situations.
              </p>
            </div>
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-medium text-blue-800 mb-2">Universal Recipient (AB+)</h4>
              <p className="text-gray-700">
                AB+ individuals can receive blood from any donor type. 
                However, they can only donate to other AB+ recipients.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BloodTypeInfoSection;