import React from 'react';
import { Heart, Droplet, Users, MapPin } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const HeroSection: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="relative overflow-hidden bg-gradient-to-r from-red-500 to-red-600 text-white">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-white"></div>
        <div className="absolute top-1/4 right-1/4 w-64 h-64 rounded-full bg-white"></div>
        <div className="absolute bottom-0 right-0 w-80 h-80 rounded-full bg-white"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Every Drop Counts. <br />
              <span className="text-white">Save Lives Today.</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-red-100">
              Connecting blood donors with recipients in real-time. Your donation can save up to three lives.
            </p>
            
            <div className="flex flex-wrap gap-4">
              {isAuthenticated ? (
                <>
                  <a 
                    href="/donate" 
                    className="px-6 py-3 rounded-full bg-white text-red-600 font-semibold text-lg shadow-lg hover:bg-red-50 transform hover:scale-105 transition-all"
                  >
                    Donate Now
                  </a>
                  <a 
                    href="/request" 
                    className="px-6 py-3 rounded-full bg-transparent border-2 border-white text-white font-semibold text-lg hover:bg-white hover:text-red-600 transform hover:scale-105 transition-all"
                  >
                    Request Blood
                  </a>
                </>
              ) : (
                <>
                  <a 
                    href="/register" 
                    className="px-6 py-3 rounded-full bg-white text-red-600 font-semibold text-lg shadow-lg hover:bg-red-50 transform hover:scale-105 transition-all"
                  >
                    Register Now
                  </a>
                  <a 
                    href="/login" 
                    className="px-6 py-3 rounded-full bg-transparent border-2 border-white text-white font-semibold text-lg hover:bg-white hover:text-red-600 transform hover:scale-105 transition-all"
                  >
                    Sign In
                  </a>
                </>
              )}
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4">
              <div className="flex flex-col items-center">
                <div className="rounded-full bg-white p-3 mb-2">
                  <Droplet size={24} className="text-red-600" />
                </div>
                <span className="text-sm font-medium">All Blood Types</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="rounded-full bg-white p-3 mb-2">
                  <MapPin size={24} className="text-red-600" />
                </div>
                <span className="text-sm font-medium">Location Based</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="rounded-full bg-white p-3 mb-2">
                  <Users size={24} className="text-red-600" />
                </div>
                <span className="text-sm font-medium">500+ Donors</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="rounded-full bg-white p-3 mb-2">
                  <Heart size={24} className="text-red-600" />
                </div>
                <span className="text-sm font-medium">Real-time Matching</span>
              </div>
            </div>
          </div>
          
          <div className="hidden lg:flex justify-center">
            <div className="relative w-96 h-96">
              {/* Animated blood drop */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative">
                  <div className="w-32 h-48 bg-white rounded-t-full animate-pulse"></div>
                  <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-48 h-48 bg-white rounded-full"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Heart size={80} className="text-red-600 animate-beat" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Wave shape divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="w-full h-auto">
          <path 
            fill="#ffffff" 
            fillOpacity="1" 
            d="M0,224L48,213.3C96,203,192,181,288,181.3C384,181,480,203,576,202.7C672,203,768,181,864,186.7C960,192,1056,224,1152,229.3C1248,235,1344,213,1392,202.7L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          ></path>
        </svg>
      </div>
    </div>
  );
};

export default HeroSection;