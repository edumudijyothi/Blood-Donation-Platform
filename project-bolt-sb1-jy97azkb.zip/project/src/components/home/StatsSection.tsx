import React from 'react';
import { Users, Heart, Calendar, MapPin } from 'lucide-react';

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  description: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, description }) => {
  return (
    <div className="bg-white rounded-lg shadow p-6 text-center hover:shadow-lg transition-shadow">
      <div className="inline-flex items-center justify-center w-12 h-12 bg-red-100 rounded-full mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mb-2">{title}</h3>
      <p className="text-3xl font-bold text-red-600 mb-2">{value}</p>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const StatsSection: React.FC = () => {
  return (
    <section className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Impact</h2>
          <p className="max-w-2xl mx-auto text-lg text-gray-600">
            Together, we're making a difference in communities across the region. 
            See the impact of our collective effort.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard 
            icon={<Users className="h-6 w-6 text-red-600" />}
            title="Registered Donors"
            value="500+"
            description="Active donors ready to help"
          />
          <StatCard 
            icon={<Heart className="h-6 w-6 text-red-600" />}
            title="Lives Saved"
            value="1,500+"
            description="Through successful donations"
          />
          <StatCard 
            icon={<Calendar className="h-6 w-6 text-red-600" />}
            title="Donations"
            value="850+"
            description="Completed in the last year"
          />
          <StatCard 
            icon={<MapPin className="h-6 w-6 text-red-600" />}
            title="Communities"
            value="75+"
            description="Served across the region"
          />
        </div>
        
        <div className="mt-12 text-center">
          <a 
            href="/about"
            className="inline-flex items-center px-6 py-3 rounded-full border-2 border-red-600 text-red-600 font-semibold hover:bg-red-600 hover:text-white transition-colors"
          >
            Learn More About Our Mission
          </a>
        </div>
      </div>
    </section>
  );
};

export default StatsSection;