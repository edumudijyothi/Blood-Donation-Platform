import React, { useState } from 'react';
import { BloodType } from '../../types';

interface RequestFormProps {
  onSubmit: (data: FormData) => void;
}

interface FormData {
  bloodType: BloodType;
  quantity: string;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  hospitalName: string;
  requiredDate: string;
  patientName?: string;
  contactPhone: string;
  medicalNotes?: string;
  location: {
    address: string;
    city: string;
    state: string;
    zipCode: string;
  }
}

const RequestForm: React.FC<RequestFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState<FormData>({
    bloodType: 'A+',
    quantity: '1 unit',
    urgency: 'medium',
    hospitalName: '',
    requiredDate: '',
    patientName: '',
    contactPhone: '',
    medicalNotes: '',
    location: {
      address: '',
      city: '',
      state: '',
      zipCode: ''
    }
  });
  
  const bloodTypes: BloodType[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent as keyof FormData],
          [child]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Request Blood</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Blood Type Required*</label>
            <select 
              name="bloodType"
              value={formData.bloodType}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
              required
            >
              {bloodTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Quantity Needed*</label>
            <input 
              type="text"
              name="quantity"
              value={formData.quantity}
              onChange={handleChange}
              placeholder="E.g., 2 units"
              className="input-field"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Urgency Level*</label>
            <select 
              name="urgency"
              value={formData.urgency}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
              required
            >
              <option value="low">Low - Within weeks</option>
              <option value="medium">Medium - Within days</option>
              <option value="high">High - Within 24 hours</option>
              <option value="critical">Critical - Immediate need</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Required By Date*</label>
            <input 
              type="date"
              name="requiredDate"
              value={formData.requiredDate}
              onChange={handleChange}
              className="input-field"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Hospital/Clinic Name*</label>
            <input 
              type="text"
              name="hospitalName"
              value={formData.hospitalName}
              onChange={handleChange}
              placeholder="Enter hospital name"
              className="input-field"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Patient Name (Optional)</label>
            <input 
              type="text"
              name="patientName"
              value={formData.patientName}
              onChange={handleChange}
              placeholder="Patient name (optional)"
              className="input-field"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Contact Phone*</label>
            <input 
              type="tel"
              name="contactPhone"
              value={formData.contactPhone}
              onChange={handleChange}
              placeholder="Contact phone number"
              className="input-field"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Address*</label>
            <input 
              type="text"
              name="location.address"
              value={formData.location.address}
              onChange={handleChange}
              placeholder="Street address"
              className="input-field"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">City*</label>
            <input 
              type="text"
              name="location.city"
              value={formData.location.city}
              onChange={handleChange}
              placeholder="City"
              className="input-field"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">State*</label>
            <input 
              type="text"
              name="location.state"
              value={formData.location.state}
              onChange={handleChange}
              placeholder="State/Province"
              className="input-field"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Zip Code*</label>
            <input 
              type="text"
              name="location.zipCode"
              value={formData.location.zipCode}
              onChange={handleChange}
              placeholder="Zip/Postal code"
              className="input-field"
              required
            />
          </div>
        </div>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">Medical Notes (Optional)</label>
          <textarea
            name="medicalNotes"
            value={formData.medicalNotes}
            onChange={handleChange}
            placeholder="Any relevant medical information or special requirements"
            className="w-full p-3 border border-gray-300 rounded-lg h-32 focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
          ></textarea>
        </div>
        
        <div className="bg-red-50 p-4 rounded-lg mb-6">
          <h3 className="text-red-800 font-medium mb-2">Important Notice</h3>
          <p className="text-sm text-gray-700">
            By submitting this form, you understand that this is a request for blood donation and 
            not a guarantee. Our system will attempt to match you with eligible donors based on 
            blood type compatibility and location. For critical cases, please also contact your 
            local hospitals directly.
          </p>
        </div>
        
        <div className="flex justify-end">
          <button 
            type="submit" 
            className="px-6 py-3 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors"
          >
            Submit Request
          </button>
        </div>
      </form>
    </div>
  );
};

export default RequestForm;