// Types for the blood donation platform

export type BloodType = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export type UserRole = 'donor' | 'recipient' | 'hospital' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  location: Location;
  phone?: string;
  profileImage?: string;
  createdAt: Date;
}

export interface Donor extends User {
  bloodType: BloodType;
  lastDonation?: Date;
  donationCount: number;
  eligibleToDonateSince?: Date;
  medicalConditions: string[];
  badges: Badge[];
}

export interface Recipient extends User {
  bloodType: BloodType;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  hospitalName?: string;
  medicalConditions: string[];
  requiredAmount?: string;
}

export interface Hospital {
  id: string;
  name: string;
  location: Location;
  phone: string;
  email: string;
  inventoryStatus: InventoryStatus[];
}

export interface Location {
  latitude: number;
  longitude: number;
  address: string;
  city: string;
  state: string;
  country: string;
  zipCode: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earnedAt: Date;
}

export interface DonationRequest {
  id: string;
  recipient: Recipient;
  bloodType: BloodType;
  quantity: string;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  status: 'pending' | 'matched' | 'fulfilled' | 'cancelled';
  hospital?: Hospital;
  createdAt: Date;
  matchedDonors?: Donor[];
  notes?: string;
}

export interface DonationAppointment {
  id: string;
  donor: Donor;
  hospital: Hospital;
  scheduledFor: Date;
  status: 'scheduled' | 'completed' | 'cancelled' | 'no-show';
  bloodType: BloodType;
  notes?: string;
}

export interface InventoryStatus {
  bloodType: BloodType;
  quantity: string;
  lastUpdated: Date;
  status: 'low' | 'medium' | 'adequate' | 'high';
}

export interface EducationalResource {
  id: string;
  title: string;
  description: string;
  imageUrl?: string;
  link: string;
  category: 'eligibility' | 'process' | 'benefits' | 'myth-busting' | 'general';
}